LIFEPATH: EVERY CHOICE COUNTS — iPhone Home Screen build

This folder contains the browser game and PWA support files (manifest, service worker, icons). The original master prompt remains in specification/ unchanged.

IMPORTANT: iPhone Home Screen installation requires the game to be hosted at an HTTPS website. A ZIP or local file cannot be installed as a true web app directly from the Files app. Upload the contents of this folder to a static HTTPS host (for example, GitHub Pages). Keep index.html, manifest.json, sw.js, and icons/ together at the same site path.

INSTALL ON iPHONE 12
1. Open the published HTTPS game URL in Safari (not an in-app browser).
2. Tap Share (square with upward arrow).
3. Scroll and tap “Add to Home Screen”.
4. Name it LIFEPATH and tap Add.
5. Tap the new LIFEPATH icon on your Home Screen to launch it.

The service worker caches the app shell for subsequent launches after the first successful visit. Game save persistence depends on the game's own browser storage. This package does not itself publish or host the site.
